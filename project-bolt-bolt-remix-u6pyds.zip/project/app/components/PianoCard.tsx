import { motion } from "framer-motion";
import type { Piano } from "~/data/pianos";

interface PianoCardProps {
  piano: Piano;
  size?: "small" | "large";
}

export function PianoCard({ piano, size = "small" }: PianoCardProps) {
  const isLarge = size === "large";
  
  const handleDetailsClick = () => {
    alert(`
      ${piano.brand} ${piano.model} (${piano.year})
      
      Price: $${piano.price.toLocaleString()}
      Condition: ${piano.condition}
      Location: ${piano.location}
      
      ${piano.description}
    `);
  };
  
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className={`group relative overflow-hidden rounded-xl bg-gray-100 dark:bg-gray-800 ${
        isLarge ? "md:col-span-2" : ""
      }`}
    >
      <div className="aspect-square overflow-hidden">
        <img
          src={piano.image}
          alt={`${piano.brand} ${piano.model}`}
          className="h-full w-full object-cover transition-all duration-300 group-hover:scale-105 group-hover:blur-sm"
        />
      </div>
      
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 via-gray-900/40 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      
      {/* Content */}
      <div className="absolute bottom-0 w-full p-4">
        <div className="transform space-y-3 transition-transform duration-300">
          <h3 className="text-lg font-semibold text-white">
            {piano.brand} {piano.model}
          </h3>
          <p className="text-sm text-gray-300">{piano.year}</p>
          <p className="text-lg font-bold text-white">
            ${piano.price.toLocaleString()}
          </p>
          <div className="flex items-center gap-2">
            <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium
              ${piano.condition === 'Excellent' ? 'bg-green-500/20 text-green-400' :
                piano.condition === 'Good' ? 'bg-yellow-500/20 text-yellow-400' :
                'bg-red-500/20 text-red-400'}`}>
              {piano.condition}
            </span>
            <span className="text-sm text-gray-300">{piano.location}</span>
          </div>
        </div>
      </div>

      {/* Centered Details Button - Only visible on hover */}
      <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <motion.button
          initial={false}
          whileHover={{ scale: 1.05 }}
          onClick={handleDetailsClick}
          className="rounded-md bg-white px-6 py-3 text-sm font-medium text-gray-900 shadow-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
        >
          View Details
        </motion.button>
      </div>
    </motion.div>
  );
}