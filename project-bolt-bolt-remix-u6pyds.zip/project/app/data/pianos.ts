export interface Piano {
  id: string;
  brand: string;
  model: string;
  year: number;
  condition: 'Excellent' | 'Good' | 'Fair';
  price: number;
  description: string;
  image: string;
  location: string;
}

export const pianos: Piano[] = [
  {
    id: '1',
    brand: 'Steinway & Sons',
    model: 'Model B',
    year: 1998,
    condition: 'Excellent',
    price: 85000,
    description: 'Beautiful Steinway Model B in excellent condition. Regular maintenance, one owner.',
    image: '/pianos/steinway-b.jpg',
    location: 'New York, NY'
  },
  {
    id: '2',
    brand: 'Yamaha',
    model: 'C7X',
    year: 2015,
    condition: 'Excellent',
    price: 45000,
    description: 'Professional grade concert grand piano. Perfect for performance venues.',
    image: '/pianos/yamaha-c7x.jpg',
    location: 'Los Angeles, CA'
  },
  {
    id: '3',
    brand: 'Bösendorfer',
    model: '200',
    year: 1985,
    condition: 'Good',
    price: 65000,
    description: 'Classic Bösendorfer sound. Some wear but mechanically perfect.',
    image: '/pianos/bosendorfer-200.jpg',
    location: 'Chicago, IL'
  },
  {
    id: '4',
    brand: 'Kawai',
    model: 'SK-5',
    year: 2018,
    condition: 'Excellent',
    price: 55000,
    description: 'Semi-concert grand in pristine condition. Includes artist bench.',
    image: '/pianos/kawai-sk5.jpg',
    location: 'Miami, FL'
  },
  {
    id: '5',
    brand: 'Baldwin',
    model: 'SD-10',
    year: 1978,
    condition: 'Fair',
    price: 18000,
    description: 'Vintage concert grand. Needs some restoration but great potential.',
    image: '/pianos/baldwin-sd10.jpg',
    location: 'Seattle, WA'
  },
  {
    id: '6',
    brand: 'Fazioli',
    model: 'F278',
    year: 2020,
    condition: 'Excellent',
    price: 195000,
    description: 'Nearly new Fazioli concert grand. Exceptional Italian craftsmanship.',
    image: '/pianos/fazioli-f278.jpg',
    location: 'Boston, MA'
  }
];