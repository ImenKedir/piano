import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData, Link } from "@remix-run/react";
import { Header } from "~/components/Header";
import { pianos } from "~/data/pianos";

export async function loader({ params }: LoaderFunctionArgs) {
  const piano = pianos.find(p => p.id === params.id);
  
  if (!piano) {
    throw new Response("Piano not found", { status: 404 });
  }

  return json({ piano });
}

export default function PianoDetails() {
  const { piano } = useLoaderData<typeof loader>();

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      <Header />
      <main className="container mx-auto px-4 pt-24 pb-16">
        <div className="max-w-5xl mx-auto">
          <Link
            to="/"
            className="inline-flex items-center gap-2 mb-6 text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              className="w-5 h-5"
            >
              <path
                fillRule="evenodd"
                d="M17 10a.75.75 0 01-.75.75H5.612l4.158 3.96a.75.75 0 11-1.04 1.08l-5.5-5.25a.75.75 0 010-1.08l5.5-5.25a.75.75 0 111.04 1.08L5.612 9.25H16.25A.75.75 0 0117 10z"
                clipRule="evenodd"
              />
            </svg>
            Back to Listings
          </Link>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="aspect-square overflow-hidden rounded-xl bg-gray-100 dark:bg-gray-800">
              <img
                src={piano.image}
                alt={`${piano.brand} ${piano.model}`}
                className="h-full w-full object-cover"
              />
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                  {piano.brand} {piano.model}
                </h1>
                <p className="text-xl font-bold text-gray-900 dark:text-white">
                  ${piano.price.toLocaleString()}
                </p>
              </div>

              <div className="flex items-center gap-4">
                <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-sm font-medium
                  ${piano.condition === 'Excellent' ? 'bg-green-500/20 text-green-400' :
                    piano.condition === 'Good' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'}`}>
                  {piano.condition}
                </span>
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  Year: {piano.year}
                </span>
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {piano.location}
                </span>
              </div>

              <div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Description
                </h2>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  {piano.description}
                </p>
              </div>

              <button
                className="w-full md:w-auto inline-flex h-12 items-center justify-center rounded-md bg-gray-900 px-8 text-sm font-medium text-gray-50 shadow transition-colors hover:bg-gray-900/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-gray-950 disabled:pointer-events-none disabled:opacity-50 dark:bg-gray-50 dark:text-gray-900 dark:hover:bg-gray-50/90 dark:focus-visible:ring-gray-300"
                onClick={() => alert("Contact feature coming soon!")}
              >
                Contact Seller
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}